<?php $navmenu = array(
	'theme_location'  => 'primary',
	'menu'            => '', 
	'container'       => 'false', 
	'container_class' => '', 
	'container_id'    => '',
	'menu_class'      => '', 
	'menu_id'         => '',
	'echo'            => true,
	'fallback_cb'     => 'false',
	'before'          => '',
	'after'           => '',
	'link_before'     => '',
	'link_after'      => '',
	'items_wrap'      => /* Don't wrap in a UL */ '%3$s',
	'depth'           => 1,
	'walker'          => ''
); ?>

<div class="page-wrap">
	<div id="logo">
		<a title="Shero Designs" href="<?php bloginfo('wpurl'); ?>">shero</a>
		<span class="logo-left"></span>
		<span class="logo-right"></span>
	</div>
	<nav id="menu" class="navmenu">
		<span class="menu-icon">Toggle Menu</span>
		<a class="nav-cta">
			Get a Quote
		</a>
		<ul>
			<?php wp_nav_menu( $navmenu ); ?>
			<li class="search-icon"><a href="#search"><span class="fa fa-search"><span>Search</span></span></a></li>
		</ul>
	</nav>
</div>

<script>
	(function() {

		"use strict";

		var toggles = document.querySelectorAll(".navmenu");

		for (var i = toggles.length - 1; i >= 0; i--) {
			var toggle = toggles[i];
			toggleHandler(toggle);
		};

		function toggleHandler(toggle) {
			toggle.addEventListener( "click", function(e) {
				e.preventDefault();
				(this.classList.contains("is-active") === true) ? this.classList.remove("is-active") : this.classList.add("is-active");
			});
		}

	})();
</script>